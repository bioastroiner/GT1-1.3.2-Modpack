package gregtechmod.api;

import net.minecraft.src.ItemStack;

/**
 * This File contains the functions used to get Items and add Recipes. Please do not include this File in your Moddownload as it maybe ruins compatiblity, like with the IC�-API
 */
public class GregTech_API {
	private static boolean isGregTechLoaded = false;
	
	/**
	 * Do not use this Function unless you are me!
	 * I use this to easily determine if my Addon is loaded.
	 * I call it in the constructor of my Main-Addon-File.
	 */
	public static void setGregTechLoaded() {isGregTechLoaded = true;}
	
	/**
	 * Gets true in the PreInitPhase of the GregTechAddon
	 */
	public static boolean isGregTechLoaded() {return isGregTechLoaded;}
	
	/**
	 * Gets a Block from my Addon.
	 * @param aIndex Index of my Item:
	 * 0 Standardblock,
	 * 1 Machineblock,
	 * 2 Oreblock,
	 * 3 That glowing thing from my Lighthelmet.
	 * @param aAmount Amount of the Item in the returned Stack
	 * @param aMeta The Metavalue of the Block
	 * @return The ItemStack you ordered, if not then look at the Log.
	 */
	public static ItemStack getGregTechBlock(int aIndex, int aAmount, int aMeta) {
		if (isGregTechLoaded()) {
			try {
				return (ItemStack)Class.forName("gregtechmod.GT_Mod").getMethod("getGregTechBlock", int.class, int.class, int.class).invoke(null, aIndex, aAmount, aMeta);
			} catch (Exception e) {
				System.err.println(e);
			}
		}
		return null;
	}
	
	/**
	 * Ever wondered out of how many Tincells an Item consists? Find it out.
	 * You could also check if the targetItem implements ICapsuleCellContainer, to not be relent on the Code in my Addon, but this also outputs values for IC�-Items
	 * @param aStack the Stack of the Item
	 * @return The amount of Tincells in ONE of the Items from the Stack
	 */
	public static int getCapsuleCellContainerCount(ItemStack aStack) {
		if (isGregTechLoaded()) {
			try {
				return (Integer)Class.forName("gregtechmod.GT_Mod").getMethod("getCapsuleCellContainerCount", ItemStack.class).invoke(null, aStack);
			} catch (Exception e) {
				System.err.println(e);
			}
		}
		return 0;
	}
	
	
	
	
	/**
	 * Gets an Item from my Addon. The Indizes are the same, as the ones at the items.png
	 * @param aIndex Index of my Item
	 * @param aAmount Amount of the Item in the returned Stack
	 * @return The ItemStack you ordered, if not then look at the Log.
	 */
	public static ItemStack getGregTechItem(int aIndex, int aAmount) {
		if (isGregTechLoaded()) {
			try {
				return (ItemStack)Class.forName("gregtechmod.GT_Mod").getMethod("getGregTechItem", int.class, int.class).invoke(null, aIndex, aAmount);
			} catch (Exception e) {
				System.err.println(e);
			}
		}
		return null;
	}
	
	/**
	 * Adds a FusionreactorRecipe
	 * @param aInput1 = first Input (not null, and respects StackSize)
	 * @param aInput2 = second Input (not null, and respects StackSize)
	 * @param aOutput = Output of the Fusion (can be null, and respects StackSize)
	 * @param aFusionDurationInTicks = How many ticks the Fusion lasts (must be > 0)
	 * @param aFusionEnergyPerTick = The EU generated per Tick (can even be negative!)
	 * @param aEnergyNeededForStartingFusion = EU needed for heating the Reactor up (must be >= 0)
	 * @return true if the Recipe got added, otherwise false.
	 */
	public static boolean addFusionReactorRecipe(ItemStack aInput1, ItemStack aInput2, ItemStack aOutput, int aFusionDurationInTicks, int aFusionEnergyPerTick, int aEnergyNeededForStartingFusion) {
		if (isGregTechLoaded()) {
			try {
				Class.forName("gregtechmod.GT_Mod").getMethod("addFusionReactorRecipe", ItemStack.class, ItemStack.class, ItemStack.class, int.class, int.class, int.class).invoke(null, aInput1, aInput2, aOutput, aFusionDurationInTicks, aFusionEnergyPerTick, aEnergyNeededForStartingFusion);
				return true;
			} catch (Exception e) {
				System.err.println(e);
			}
		}
		return false;
	}
	
	/**
	 * Adds a CentrifugeRecipe
	 * Note that when the Centrifuge outputs empty Cells, these will automatically be moved to the CellInputSlot
	 * @param aInput1 must be != null
	 * @param aCellInput this is for the needed Cells, > 0 for Tincellcount, < 0 for negative Fuelcancount, == 0 for nothing
	 * @param aOutput1 must be != null
	 * @param aOutput2 can be null
	 * @param aOutput3 can be null
	 * @param aOutput4 can be null
	 * @param aDuration must be > 0
	 */
	public static boolean addCentrifugeRecipe(ItemStack aInput1, int aCellInput, ItemStack aOutput1, ItemStack aOutput2, ItemStack aOutput3, ItemStack aOutput4, int aDuration) {
		if (isGregTechLoaded()) {
			try {
				Class.forName("gregtechmod.GT_Mod").getMethod("addCentrifugeRecipe", ItemStack.class, int.class, ItemStack.class, ItemStack.class, ItemStack.class, ItemStack.class, int.class).invoke(null, aInput1, aCellInput, aOutput1, aOutput2, aOutput3, aOutput4, aDuration);
				return true;
			} catch (Exception e) {
				System.err.println(e);
			}
		}
		return false;
	}
	
	/**
	 * Adds a Sound to the Sonictron9001
	 * you should NOT call this in the preInit-Phase!
	 * @param aItemStack = The Item you want to display for this Sound
	 * @param aSoundName = The Name of the Sound in the resources/newsound-folder like Vanillasounds
	 * @return true if the Sound got added, otherwise false.
	 */
	public static boolean addSonictronSound(ItemStack aItemStack, String aSoundName) {
		if (isGregTechLoaded()) {
			try {
				Class.forName("gregtechmod.GT_Mod").getMethod("addSonictronSound", ItemStack.class, String.class).invoke(null, aItemStack, aSoundName);
				return true;
			} catch (Exception e) {
				System.err.println(e);
			}
		}
		return false;
	}
}
