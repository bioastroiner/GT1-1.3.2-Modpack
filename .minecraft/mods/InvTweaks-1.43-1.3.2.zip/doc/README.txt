|==============================================================|
| INVENTORY TWEAKS Mod - By Jimeo Wan (jimeo.wan at gmail.com) |
| Readme                                                       |
|==============================================================|

Need help?

* Official website: http://modding.kalam-alami.net
* Minecraft Forum thread: http://www.minecraftforum.net/topic/323444-inventory-tweaks
